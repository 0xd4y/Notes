# Things Tested on Exam
- need to know logging
	- how to handle monitoring and logging
	- how to automate responses to incidents found in those logs
- know troubleshooting
	- if logs from lambda are not showing up in cloudwatch, why is this?


Knowledge Domain | % of Exam
------------|------
Incident Response | 12%
Logging and Monitoring | 20%
Infrastructure Security | 26%
Identity and Access Management | 20%
Data Protection | 22%

- scenario-based
	- automating response to security issues
- know format of policies in json
- order in which thigs are resolved
	- explicit deny, explicit allow, default implicit deny
- know cloudwatch, KMS, IAM, cloudtrail, etc.
