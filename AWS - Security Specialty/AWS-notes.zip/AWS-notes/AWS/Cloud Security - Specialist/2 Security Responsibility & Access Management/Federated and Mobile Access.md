# Federated and Mobile Access
[[AWS Contents]]
[[AWS Questions#Federated and Mobile Access]]

- used for providing resource to a large amount of users
	- unfeasible to create individual IAM accounts for every user to access the resource
- allows access to AWS resources without IAM user account
- credentials federated by identity provider (IDP)
	- e.g. Microsoft Active Directory Accounts, Google, Facebook, etc.

<u>Security Assertion Markup Language (SAML)</u>
- allows secure exchange of authentication data between different domains
- users security tokens between an IdP and a SAML consumer

## Social Federation
### Amazon Cognito
- made for enabling secure authentication and access control for new and existing users accessing web or mobile applications
- generate tokens after  authentication that manages access 
- best practice when creating applications that require social IdPs for authentication

Two main Components:

1. User Pools
	- scalable user directories
	- allow users to login to mobile application
	- ![[Pasted image 20220203163059.png]]
2. Identity Pools
	- assigns permissions to user to access AWS resources (uses temporary credentials
	- ![[Pasted image 20220203163348.png]]

