# Shared Responsibility Model
[[AWS Contents]]
[[AWS Questions#Shared Responsibility Model]]

Three different shared responsibility models:
1. Infrastructure
	- most common model
	- covers infrastructure as a Service (IaaS) services such as Elastic Compute Cloud (EC2)
	- ![[Pasted image 20220131154703.png]]
	- AWS responsible for security of the cloud, customer is responsible for security in the cloud
2. Container
	- customer does not have access to some of infrastructure-level components such as the operating system
	- examples of services in container model: Elastic MapReduce (EMR), Relational Database Service (RDS), Elastic Beanstalk
	- ![[Pasted image 20220131161816.png]]
	- AWS has more responsibilities with this model than the infrastructure model
		- platform and application management, operating system, and network configuration are responsibility of AWS
3. Abstract
	- ![[Pasted image 20220131162045.png]]
	- AWS responsible for even more security
		- in addition manages server-side encryption and network traffic protection
	- examples of services in abstract model: Simple Queue Service (SQS), DynamoDB, and S3
	- accessed through endpoints
		- no access to operating system (infrastructure) or platform running these services (container)