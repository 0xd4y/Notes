# Identity and Access Management (IAM)
[[AWS Contents]]
[[AWS Questions]]

- contains details and credentials of root user account
- access keys should not be configured for root user (additional user with relevant privileges should be created instead)
	- limit access methods to root account

## Groups
- groups are associated with set of permissions allowing members of that group to inherit those permissions
	- groups don't have credentials associated with it
	- object within IAM

## Roles
- associated set of permissions that allows access to AWS resources
	- not associated with users or groups
	- sort of works like discord roles
### Examples of roles:
#### Service Roles
- allows other AWS services to perform actions on one's behalf
- only exist in account in which they were created (can't be used for cross-account access)
- when using EC2 roles for deploying and running EC2 instances, it is best practice to associate EC2 instances with a role (removes the need to store credentials on any instance)
	- role itself
	- instance profile
		- container for role
		- used to pass data to EC2 instance


#### User Roles
- when user assumes a role, their current permissions get temporarily replaced by the role's permissions

#### Web Identity Federate Role
- allows a single sign on (SSO) approach
- federated access means user has been authenticated by external source 
	- can be through well-known identity providers (IDPs) such as Amazon, Google, or Facebook

#### SAML 2.0 federated roles
- allows creation of roles that have been federated through one's internal corporate directory 
- the external authentication system is one's own corporate directory of users
	- e.g. Microsoft Active Directory (MSAD) 