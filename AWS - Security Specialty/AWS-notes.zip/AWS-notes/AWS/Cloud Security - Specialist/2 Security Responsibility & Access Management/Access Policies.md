# Access Policies 
[[AWS Contents]]
[[AWS Questions#Access Policies]]

- define who or what can or can't access AWS resources

<u>Policy Structure</u>:
1. Version
	- shows version of policy language
2. Statement
	- acts as group for parameters in json structure
3. Sid
	- statement identification
4. Effect
	- can be either *allow* or *deny*
		- allows or denies access to resource
5. Action
	- list of actions to be allowed or denied access to
		- action is first defined by service and then preceded with action
6. Resource
	- provides Amazon Resource Name (ARN)
		- tells which resource the permissions apply to 
7. Condition
	- optional
	- dictates under what conditions policy is in effect
	
![[Pasted image 20220131192503.png]]
- Policy Types:
	## Identity-based Policies
	- attached to IAM user, group, or role
	- controls what actions an identity (users, groups of users, roles) can perform on which resources and under what conditions
		- e.g. allowing user John to run the EC2 `RunInstances` action 
	- can be AWS-managed, customer-managed or in-line policies
		### AWS-managed
		- policies that are created and managed by AWS
		### Customer-managed
		- custom policy that is made by the customer 
		### In-line 
		- added directly to user, group, or role
		- deleted when the identity is deleted
	## Resource-based Policies
	- very similar to in-line policies except they are attached to resources instead of identities
	- can be attached to buckets and S3 objects
	- lets you specify who has access to resource and what actions they can perform on it
	- policy looks the same as in the example policy, however includes a *Principal* parameter
		- identifies user, role, account, or federated user that permissions should be applied to
	## Permissions boundaries
	- governs maximum permissions an identity-based policy can associate with any user or role
	## Access Control Lists (ACLs)
	- can attach to buckets and S3 objects
	- similar to resource-based policies
	- use only to control cross-account access from different AWS account or public access
	## Organization SCPs
	- SCP stands for Service Control Policy
	- used by AWS organizations to manage multiple AWS accounts
	- similar to permissions boundaries within identity objects
		- they also set maximum permission level that can be given to members of an AWS account or organization unit (OU)
		- restrict permissions for resource-based and identity-based policies
		- restricts permissions, doesn't grant permissions

## Policy evaluation
Determination of permissions when accessing resource:
1. Authentication
2. Determine context of request
	- request processed and associated permissions are defined
	- actions, resources, principals, environment data, and resource data are examined
3. Policy evaluation
	- policy types evaluated in order of identity-based, resource-based, IAM permissions boundaries, and SCPs
4. Permission Result
	- access granted or denied

- deny actions overrule allow actions 
