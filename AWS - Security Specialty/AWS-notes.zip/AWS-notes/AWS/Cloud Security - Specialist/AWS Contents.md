# Table of Contents
[[AWS Questions]]
[[AWS/Cloud Security - Specialist/Misc|Misc]]
## Section 2: Security Responsibility & Access Management
[[Access Management]]
[[Access Policies]]
[[Federated and Mobile Access]]
[[Shared Responsibility Model]]

## Section 3: Security - A Layered Approach

[[Configuring Infrastructure Security]]
[[Implementing Application Security]]
[[Securing EC2 Instances]]
[[DDoS Protection]]
[[Incident Response]]
[[Secure Connections to AWS Environment]]

## Section 4: Monitoring, Logging, and Auditing
[[Implementing Logging Mechanisms]]
[[Auditing and Governance]]

## Section 5: Best Practices and Automation
[[Automation]]
[[Discovering Security Best Practices]]

## Section 6: Encryption and Data Security
[[Managing Key Infrastructure]]
[[Managing Data Security]]