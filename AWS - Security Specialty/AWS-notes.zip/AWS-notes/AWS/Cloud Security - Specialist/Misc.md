# Misc 
[[AWS Contents]]
[[AWS Questions]]
## Notes
- AWS Artifact is a resource about compliance-related stuff
- AWS Config is a service that enables you to assess, audit, and evaluate the configurations of your AWS resources
- Amazon CloudFront is a web service that is used for distributing content 
	- delivers web content through network via edge locations (locations that are closest to the client requesting website), therefore gives client lowest latency
- CloudTrail logs can provide detailed API tracking for Amazon S3 bucket-level and object-level operations
- VPC Flow logging logs IP data going to and from designated network interfaces and stores this data in Amazon CloudWatch
- Amazon Athena is a serverless, interactive query service to query data and analyze big data in Amazon S3
- VPC peering - networking connection between two VPCs that enables traffic to be routed between them 
	- allows instances within those VPCs to communicate with each other as if they were in the same network
- Amazon S3 Glacier is a secure, durable, and extremely low-cost Amazon S3 storage class for data archiving and long-term backup
- AWS Control Tower enforces and manages governance rules for security, operations, and compliance at scale
- ACLs were the first authorization mechanism in S3. Bucket policies are the newer method, and the method used for almost all AWS services. Policies can implement very complex rules and permissions, ACLs are simplistic (they have ALLOW but no DENY).
	- A majority of modern use cases in Amazon S3 no longer require the use of ACLs, and we recommend that you disable ACLs except in unusual circumstances where you need to control access for each object individually


## Questions
What is the difference between Internet Gateway (IGW) and NAT Gateway (NGW)?

- internet gateway allows instances with public IP to access internet
- NAT gateway allows instances with no public IP to access internet

What is the difference between AWS CloudWatch and Amazon CloudTrail?

- AWS CloudWatch monitors AWS resources and applications while CloudTrail monitors activity within AWS environment