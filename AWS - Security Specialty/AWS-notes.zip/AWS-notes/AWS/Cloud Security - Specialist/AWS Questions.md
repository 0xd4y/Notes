# AWS Questions
[[AWS Contents]]
[[AWS/Cloud Security - Specialist/Misc|Misc]]

[[AWS Questions#Section 2 Security Responsibility Access Management|Section 2: Security Responsibility and Access Management]]
[[AWS Questions#Section 3 Security - A Layered Approach | Section 3: Security - A Layered Approach]]
[[AWS Questions#Section 4 Monitoring Logging and Auditing|Section 4: Monitoring, Logging, and Auditing]]
[[AWS Questions#Section 5 Best Practices and Automation | Section 5: Best Practices and Automation]]
[[AWS Questions#Section 6 Encryption and Data Security|Section 6: Encryption and Data Security]]
## Section 2: Security Responsibility & Access Management
[[Access Management]]
### Access Policies 
[[Access Policies]]
1. Which format are AWS policies written in?
```ad-note
collapse:
**JSON**
```
2. What type of policy are Amazon S3 bucket policies?
```ad-note
collapse:
**Resource-based**
```
3. What parameter is needed within a resource-based policy to identify who or what the policy should be associated with?
```ad-note
collapse:
**Principal**
```
4. After configuring cross-account access, from which account do you assume the cross-account role from – the trusted account or the trusting account?
```ad-note
collapse:
**Trusted account**
```
5. True or false: the Access Advisor tab allows you to determine when identities accessed different services.
```ad-note
collapse:
**True**
```

### Federated and Mobile Access
[[Federated and Mobile Access]]
 1. True or false: Federated access within AWS allows access to your AWS resources without needing to create any permissions.
```ad-note
collapse:
**False**
```
2. Which AWS service uses federation to manage access to web and mobile applications with ease?
```ad-note
collapse:
**Amazon Cognito**
```
3. What are the two common types of federated access with AWS?
```ad-note
collapse:
**SAML Federation and Social Federation**
```
4. What is IdP short for in relation to federated access?
```ad-note
collapse:
**Identity provider**
```
5. True or false: Identity pools actually provide you with the ability to assign permissions to users to access AWS resources used within a mobile app by using temporary credentials.
```ad-note
collapse:
**True**
```


### Shared Responsibility Model
[[Shared Responsibility Model]]
1. Which shared responsibility model offers the most customization and  control for the customer 
```ad-note
collapse:
**Infrastructure model**
```
2. Which shared responsibility model offers the least customization and  control for the customer?
```ad-note
collapse:
**Abstract**
```
3. In which model would you expect to find the EC2 service?
```ad-note
collapse:
**Infrastructure**
```
4. Which model focuses on services that essentially reside on top of infrastructure services, such as Amazon EMR and Amazon RDS?
```ad-note
collapse:
**Container**
```
5. True or false: the customer's responsibility is defined as security in the  cloud.
```ad-note
collapse:
**True**
```

## Section 3: Security - A Layered Approach
### Securing EC2 Instances
[[Securing EC2 Instances]]
1. True or False: AWS Systems Manager is a fully managed service that allows you to help secure your instances and the applications that run on top of them by performing vulnerability assessments via an agent.
```ad-note
collapse:
**False**
```
2. True or False: Amazon Inspector requires an agent to be installed to remotely run assessments.
```ad-note
collapse:
**False** (Used to be true). It now uses SSM to remove the need for installing an agent.
```
3. Is the public key of an EC2 instance key pair held by AWS or you as the customer?
```ad-note
collapse:
**AWS**
```
4. Which service is used to track and record API calls made within your AWS account?
```ad-note
collapse:
**AWS CloudTrail**
```
5. Which service allows you to easily and quickly administer and perform operational actions against your instances (both Windows and Linux-based) at scale for both on-premise resources and within AWS without having to SSH or RDP into those instances?
```ad-note
collapse:
**Systems Manager (SSM)**
```

### Configuring Infrastructure Security
[[Configuring Infrastructure Security]]
1. What does VPC stand for?
```ad-note
collapse:
**Virtual Private Cloud**
```
2.  Which VPC component provides a connection between your VPC and the outside world?
```ad-note
collapse:
**Internet Gateway (IGW)**
```
3. Which VPC component allows instances in a private subnet to initiate a connection to the internet, for example, for essential operating system updates, but prevents any inbound access to the private subnet being initiated from the internet?
```ad-note
collapse:
**NAT Gateway**
```
4. True or false: Security groups provide a virtual firewall level of protection at the instance level.
```ad-note
collapse:
**True**
```
5. True or false: Using the default NACL of your VPC provides enhanced security protection blocking all network traffic, both inbound and outbound.
```ad-note
collapse:
**False**
```

### Implementing Application Security
[[Implementing Application Security]]
1. True or false: The main function of the AWS WAF service is to provide protection for your web applications from malicious attacks from a wide variety of attack patterns.
```ad-note
collapse:
**True**
```
2. Which service allows you to manage WAF rules across a multi-account environment when using AWS Organizations?
```ad-note
collapse:
**AWS Firewall Manager**
```
3. Which AWS service must you enable as a prerequisite to use AWS Firewall Manager?
```ad-note
collapse:
**AWS Config**
```
4. Which type of load balancer would you use if low latency and high performance are key to your application architectures?
```ad-note
collapse:
**Network Load Balancer**
```

### DDoS Protection
[[DDoS Protection]]
1. Which type of DDoS attack takes advantage of the three-way handshake that is used to establish a connection between two hosts?
```ad-note
collapse:
**SYN Flood**
```
2. How many tiers are there to choose from when working with AWS
Shield?
```ad-note
collapse:
**2**
```
3. True or false: AWS Shield Advanced is a premium tier that comes with a range of additional features and protection.
```ad-note
collapse:
**True**
```
4. True or false: The DDoS Response Team (DRT) is a specialized team at AWS who can help you to review, analyze, and monitor suspected malicious activity within your account and offer help and solutions on how to resolve a potential attack.
```ad-note
collapse:
**True**
```
5. True or false: By selecting a rate-based rule, you can define the maximum number of requests from a single IP within a 30-minute time frame.
```ad-note
collapse:
**False**
```

### Incident Response
[[Incident Response]]
1. Which framework has been designed by AWS to help you transition and migrate solutions into AWS Cloud that's based on best practices and recommendations?
```ad-note
collapse:
**Cloud Adoption Framework (CAF)**
```
2. Which AWS service is a regional-based managed service that's powered by machine learning, specifically designed to be an intelligent threat detection service?
```ad-note
collapse:
**Amazon GuardDuty**
```
3. Which AWS service acts as a single-pane-of-glass view across your infrastructure, thus bringing all of your security statistical data into a single place and presented in a series of tables and graphs?
```ad-note
collapse:
**AWS Security Hub**
```
4. True or False: Having a separate AWS account to be used for forensic investigations is essential to helping you diagnose and isolate any affected resource.
```ad-note
collapse:
**True**
```

### Secure Connections to AWS Environment
[[Secure Connections to AWS Environment]]
1. When configuring a VPN connection, a VPN gateway is configured as well as what other type of gateway?
```ad-note
collapse:
**Customer Gateway**
```
2. True or false: when an end-to-end connection is established between two gateways using a VPN connection with IPsec, the connection is referred to as a tube.
```ad-note
collapse:
**False**
```
3. Does Direct Connect use a public or private network to establish a connection with AWS?
```ad-note
collapse:
**Private**
```
4. True or false: by enabling route propagation, all other routes to networks represented across your site-to-site VPN connection will be automatically added to your route table, preventing you from having to manually add them.
```ad-note
collapse:
**True**
```
## Section 4: Monitoring, Logging, and Auditing
### Implementing Logging Mechanisms
[[Implementing Logging Mechanisms]]
1. True or false: Amazon S3 server access logging is enabled by default.
```ad-note
collapse:
**False**
```
2. Amazon S3 object-level logging closely integrates with which other AWS service?
```ad-note
collapse:
**AWS CloudTrail**
```
3. Which logging feature allows you the ability to capture IP traffic across the network interfaces attached to your resources?
```ad-note
collapse:
**VPC Flow Logs**
```
4. True or false: A VPC Flow Log can be configured for a subnet with a VPC.
```ad-note
collapse:
**True**
```
5. Which AWS service can be used to easily query AWS CloudTrail logs, enabling you to search for specific data?
```ad-note
collapse:
**Amazon Athena**
```

### Auditing and Governance
[[Auditing and Governance]]
1. Which AWS service is an on-demand portal to allow you to view and download AWS security and compliance reports, in addition to any online agreements?
```ad-note
collapse:
**AWS Artifact**
```
2. Which security feature of AWS CloudTrail ensures that your log files have not been tampered with or modified after they have been written to your bucket in Amazon S3?
```ad-note
collapse:
**Logfile Validation**
```
3. Which feature in AWS Config automatically monitors your resources to ensure they are meeting specific compliance controls?
```ad-note
collapse:
**AWS Managed Rules**
```
4. Which service is backed by machine learning and provides an automatic way of detecting, protecting, and classifying data within your S3 buckets?
```ad-note
collapse:
**Amazon Macie**
```
5. True or false: Amazon Macie classifies data through a series of automatic content classification mechanisms. It performs its classification using the object-level API data events collated from CloudTrail logs.
```ad-note
collapse:
**True**
```

## Section 5: Best Practices and Automation
### Automation
[[Automation]]
1. True or false: CloudWatch events can be used to search for specific events within your infrastructure, which can trigger an automated response.
```ad-note
collapse:
**True**
```
2. Amazon GuardDuty is able to process and analyze millions of events that are captured through your AWS CloudTrail logs, DNS logs, and which other logging mechanism?
```ad-note
collapse:
**VPC Flow Logs**
```
3. Which AWS service acts as a single-pane-of-glass approach to your security notifications across your accounts?
```ad-note
collapse:
**AWS Security Hub**
```
4. True or false: AWS Security Hub integrates with AWS Trusted Advisor to help you automate the remediation process of any findings found.
```ad-note
collapse:
**False**
```

### Discovering Security Best Practices
[[Discovering Security Best Practices]]
1. True or false: You should enable access keys for your root account that would enable programmatic access to your AWS account.
```ad-note
collapse:
**False**
```
2. Which AWS service highlights and recommends enhancements against a number of predefined best practice checks across five different areas of your account?
```ad-note
collapse:
**AWS Trusted Advisor**
```
3. Which check within AWS Trusted Advisor is used to determine whether you have adequate resiliency built into your environment, for example, through making use of multi-Availability Zone features and auto-scaling?
```ad-note
collapse:
**Fault Tolerance**
```
4. Which support plans only give access to seven core Trusted Advisor checks?
```ad-note
collapse:
**Basic and Developer**
```
5. True or false: A penetration test, or pentest, is essentially an authorized cyber attack on your own environment and infrastructure in an effort to determine its weak points and vulnerabilities, in addition to its strengths, against defined security standards.
```ad-note
collapse:
**True**
```

## Section 6: Encryption and Data Security
### Managing Key Infrastructure
[[Managing Key Infrastructure]]
1. True or False: Asymmetric encryption uses a single key to encrypt and decrypt data.
```ad-note
collapse:
**False**
```
2. Which component is the main building block of the KMS service as it contains the key material used for both encrypting and decrypting data?
```ad-note
collapse:
**Customer Master Key (CMK)**
```
3. There are three different types of CMKs used by KMS that you need to be familiar with; AWS-owned, customer-managed, and which other?
```ad-note
collapse:
**AWS-managed**
```
4. Which component of KMS is used to determine who can use the key to perform cryptographic operations, such as encrypt, decrypt, and GenerateDataKey, in addition to who can administer the CMK?
```ad-note
collapse:
**Key policy**
```
5. Which AWS service offers the ability to maintain a level of security protection for any API keys, in addition to other secrets?
```ad-note
collapse:
**AWS Secrets Manager**
```

### Managing  Data Security
[[Managing Data Security]]
1. What does IOPS stand for?
```ad-note
collapse:
**Input/Output Operations Per Second**
```
2. Which AWS service provides persistent block-level storage to your EC2 instance, providing more flexibility to your instance storage capabilities?
```ad-note
collapse:
**Amazon  Elastic Block Store (EBS)**
```
3. Which AWS service is used for file-level storage and has the capacity to support access to thousands of instances at once?
```ad-note
collapse:
**Amazon Elastic File Service (EFS)**
```
4. True or false: you can enable encryption at rest using the AWS CLI, an SDK, the AWS EFS API, or the AWS Management Console.
```ad-note
collapse:
**True**
```
5.  By default, at-rest encryption using server-side encryption is enabled on all DynamoDB tables. Which AWS service is integrated to perform this encryption?
```ad-note
collapse:
**AWS Key Management Service (KMS)**
```
