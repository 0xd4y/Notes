# DDoS Protection
[[AWS Contents]]
[[AWS Questions#DDoS Protection]]
- protections include AWS Shield Advanced ($3000 a month) and AWS Shield Standard (free)
## DDoS Patterns
### SYN Floods
- abuses three-way handshake when connection is being established between client and server
![[Pasted image 20220213185859.png]]
- the final ACK completes the handshake, but this is dropped in SYN Flood attack to leave connection open

### HTTP Floods
- many GET or POST requests sent to server

### Ping of Death (POD)
- oversized ping packets sent to target
- maximum size of packet is 65,535 bytes, but with fragmentation you can send a lot of data to target

## AWS Shield
- specify ARN of resources and services Shield should protect
- Elastic IP Address (EIP) should be specified first for EC2 instance in order to use Shield on it
### AWS Shield Standard
- free
- helps protect against common DDoS attacks operating at network and transport layers

### AWS Shield Advanced
- $3000 per month
- application traffic monitoring
- monitors network, transport, and application layers
- comes with AWS DDoS Response Team (known as DRT)

### Rate-Based Rules
- counts number of requests received from IP address over 5 minutes
- can define max number of request from singe IP within 5 minutes (must be over 2000)

### AWS CloudFront and Amazon Route 53
- edge services 
- recommended to use these in conjunction with Shield to further decrease chances of compromise
- helps detect DDoS attacks
- allows for layer 3, 4, and 7 attack mitigation (also 6 in the case of CloudFront used in conjunction with AWS WAF) 