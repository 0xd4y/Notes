# Securing EC2 Instances
[[AWS Contents]]
[[AWS Questions#Securing EC2 Instances]]
- Elastic Compute Cloud (EC2) is the most common of the compute services
- can use Amazon Inspector (vulnerability scanner)

## Key Pairs
- used to allow connection to instance
- uses public key cryptography (2048 bit SSH-2 RSA)
- public key maintained by EC2 instance, private key is with customer
	- keys are unrecoverable if lost
	- public key encrypts creds, private key decrypts

## Monitoring and Logging
### AWS CloudTrail
- tracks and records API calls
- for every API call the following is tracked:
	- API that was called
	- service to which API call was made against
	- timestamp when it was called
	- source IP address of requester

### AWS Config
- logs any change to resources
- acts as resource inventory
- stores and reviews configuration history of resources
- integrates with CloudTrail
	- shows which API call made specific changes
- checks compliance rules

### Amazon CloudWatch
- most common AWS monitoring service
- monitors resource performance over time
- can be used with unified Cloud Agent to collect logs of applications

### VPC Flow Logs
- Virtual Private Cloud (VPC)
- captures all IP traffic 

## Isolation
- security group should be created so that a compromised instance can quickly be changed to this group
	- the group should not be able to communicate with any other resources 
- log data should be stored in dedicated S3 bucket
- create IAM roles that only allow read-only access to resources
	- prevents accidentally changing data on instance

## Systems Manager (SSM)
- allows to quickly administer and perform operational actions against instances without SSH or RDP
### Actions
#### Automation
- automate processes against groups of resources via SSM documents
- e.g. patching EC2 instances or creating AMI (Amazon Machine Image)

#### Run Command
- manage fleet of EC2 instances remotely and securely
- can perform maintenance and management without logging into instances
- uses SSM documents to help perform administrative tasks and configuration changes

#### Distributor
- distributes software across instances

#### State Manager
- maintains state of EC2 instances
- uses of state manager:
	- configuring network settings
	- bootstrapping instances
	- ensuring installation of agents are schedually updated
	- running scripts on instances

#### Patch Manager
- automates management of patch updates across EC2 instances
- you can create patch groups which associates a number of instances with a group
	- allows you to associate a group with a single patch baseline
	- instances not associated with patch group will receive default patch baseline