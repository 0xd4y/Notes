# Incident Response
[[AWS Contents]]
[[AWS Questions#Incident Response]]

## AWS Cloud Adoption Framework (CAF)
Addresses four primary control areas:
1. Directive Controls
	- establishes governance, risk, and compliance models
2. Preventative Controls
	- protects workloads and mitigates threats and vulnerabilities
3. Detective Controls
	- provides full visibility and transparency over operation of deployments
4. Responsive Controls
	- drives the remediation of potential deviation from security baselines

## Threat Detection and Management
### AWS GuardDuty
- regional-based managed service
- powered machine learning
- monitors logs and detects unexpected / unusual behavior

### AWS Security Hub
- brings security statistical data into single place
	- presented in series of tables and graphs
- insights - grouping of findings that meet specific criteria base from specific filters and statements
	- e.g. users with most suspicious activity, S3 buckets with public write or read permissions, EC2 instances with missing security patches, etc.

## Forensics
- recommended to have an account with preconfigured settings dedicated to forensics
	- compromised instances can be moved to forensics account
	- note that the instance cannot be moved to different AWS account
- can also create forensic instance for forensic analysis
	- could take snapshot of compromised instance / EBS volume and attach it to forensic instance

## Common Infrastructure Security Incident
Common approach in a breach scenario (blue side):
1. Capture - obtain metadata from instance
2. Protect - prevent EC2 instance from being terminated (enable termination protection)
3. Isolate - isolate instance by modifying security group or updated NACL to deny all traffic destined for IP address of instance
4. Detach - remove affected instance from any autoscaling groups
5. Deregister - remove EC2 instance from any associated ELBs
6. Snapshot - take snapshot of EBS volumes for forensics
7. Tag - highlight instance that is prepared for forensic investigation
