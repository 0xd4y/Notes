# Secure Connections to AWS Environment
[[AWS Contents]]
[[AWS Questions#Secure Connections to AWS Environment]]
- can connect securely using either VPN connection or Direct Connect connection

## AWS VPN
Uses two components:
1. Virtual Private Gateway (VPN gateway)
	- resides within AWS
	- consists of two endpoints located in different data centers
2. Customer gateway

![[Pasted image 20220215120110.png]]
- consists of two IPsec tunnel
	- <u>IPsec Tunnel</u>: secure network protocol allowing encrypted communication between two endpoints 
	- implemented at IP layer
- uses public network to establish connection
### Routing
Route table example:

Destination|Target
----|--------
10.0.0.0/16|Local
172.16.0.0/16|pcx-1234abcd
172.16.1.0/24|vgw-wxyz6789

1. First route is local route of VPC (found in every route table)
2. Second route points to target relating to VPC peering connection
3. Third route point to VPN gateway

- if packet is meant for destination that is covered by two subnets, it will go to the more specific subnet
	- e.g. if packet is meant for 172.16.1.5, it will go to the third route even though route 1 and route 2 both cover that destination
- route propagation can be enabled in VPN gateway to automatically add site-to-site VPN connections to route table

## AWS Direct Connect
- like VPN connection; joins your own infrastructure with AWS architecture as if it were a single network
- generally provides more consistent and reliable connection
- Connection runs across private network via an AWS Direct Connect location
![[Pasted image 20220216094601.png]]
Three distinct locations involved to establish link:
1. Corporate site where your own private network resides
2. AWS Direct Connect location (typically owned by AWS partner)
3. AWS VPC within specific AWS region

Prerequisites for configuring and establish connection:
1. Your organization works with an AWS Direct Connect partner who is a member of AWS Partner Network (APN)
2. Your network has co-location connection to AWS Direct Connect location
3. Your organization works with an IPS allowing connection to AWS Direct Connect

Once physical network connection to AWS Direct Connect location established, network must follow this criteria:
1. Authentication - router must support Border Gateway Protocol (BGP) and MD5
2. Network must use single-mode fiber
3. Manually configured speed and full-duplex enabled
4. 802.1Q VLAN encapsulation support enabled

### Virtual Interfaces
- connection can be partitioned into virtual interfaces 
- allows access to other AWS services other than what is within your VPC
