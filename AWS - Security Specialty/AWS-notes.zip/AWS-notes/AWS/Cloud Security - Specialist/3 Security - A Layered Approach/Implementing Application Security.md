# Implementing Application Security
[[AWS Contents]]
[[AWS Questions#Implementing Application Security]]

## AWS WAF
Three primary elements:
1. Web ACL (Access Control List)
	- contains rules and rule groups (defines what should be inspected within requests)
2. Rules
	- defines specific criteria for what web ACL should be inspecting and what action to take (allow/block/count)
3. Rule Groups
	- allows you to group a set of rules

### AWS Firewall Manager
- manages WAF rules across multi-account environment when using AWS Organizations
- uses WAF rules that are grouped together within a rule group

## Managing Security Configuration of ELBs
- ELB stands for Elastic Load Balancing
	- controls, manages, and distributes incoming requests to a specified resource group 
- can be internal or internet-facing
	- internal ELBs only have private internal IP addresses and can only serve requests originating from within VPC
	- internet-facing ELBs have public DNS names and have public and internal IP addresses
### Types of ELBs
Three different ELBs:
<u>Application Load Balancer</u>
- supports incoming traffic for web applications running HTTP or HTTPS
- allows routing of requests such as to different ports

<u>Network Load Balancer</u>
- supports millions of incoming requests per second
- ideal if low latency and high performance are priorities

<u>Classic Load Balancer</u>
Using a Classic Load Balancer instead of an Application Load Balancer has the following benefits:
-   Support for EC2-Classic
-   Support for TCP and SSL listeners
-   Support for sticky sessions using application-generated cookies

## Securing APIs
- AWS API gateway
### Controlling Access to APIs
Methods for controlling authentication and authorization:
#### IAM Roles and Policies
- using IAM, policies can be associated with user, role, or group to dictate permissions
#### IAM Tags
- can be used in conjunction with IAM policies
- used for references pertaining to security controls such as in the following example: a user being able to perform a specific action based on the resource tag 
#### Resource Policies
- attached to resources (unlike IAM which is attached to identity)
- specifies principal that has been granted or denied access to invoke associate API
#### VPC Endpoint Policies
- also a resource-based policy, but is a VPC endpoint
	- VPC endpoints allows access to AWS services using private IP addresses
- controls access to private APIs
- can be used in conjunction with API Gateway resource policies for additional security
#### Lambda Authorizers
- uses AWS Lambda functions to restrict who can invoke REST API methods
- can use bearer-based tokens or HTML headers, paths, query string parameters, and stage variables
#### Amazon Cognito User Pools
- APIs can be configured to have `COGNITO_USER_POOLS` authorizer  to authenticate users via Amazon Cognito user pool API gateway
	- token is validated before allowing access