# Configuring Infrastructure Security
[[AWS Contents]]
[[AWS Questions#Configuring Infrastructure Security]]
## Virtual Private Cloud (VPC)
- private section of AWS network
- can be public-face 

### Subnets
- can only reside in a single availability zone (e.g. only in eu-west-1bAZ)
- each subnet should be configured for a specific use (i.e. segmentation); this is security best practice
	- e.g. subnet can contain only application servers, other subnet can contain only database servers, etc.
- falls within CIDR (classless inter-domain routing) block of VPC
	- e.g. if VPC CIDR block is $10.0.0.0/16$, subnets can be the following:
		- $10.0.1.0/24$
			- $10.0.1.0$ - Network address
			- $10.0.1.1$ - AWS routing
			- $10.0.1.2$ - AWS DNS
			- $10.0.1.3$ - AWS future use
			- $10.0.1.255$ - Broadcast address
		- $10.0.2.0/24$
		- $10.0.3.0/24$
		- etc.
	- note the first address is reserved for the network address, and the last address is reserved for the broadcast address
	- AWS reserves the first three host addresses in any subnet
		- first host address reserved for internal AWS VPC routing
		- second host address for AWS DNS
		- third host address for future use
	- therefore, 251 (out of 256) available host addresses for customer use in /16 subnet
	
	<u>Route Table</u>: table subnet uses for routing traffic
	- if no route table is defined, default VPC route table is used

### Flow Logs Tab
- captures IP traffic sent between network interfaces of subnet
- captured within CloudWatch

## Internet Gateway (IGW)
- helps create a public subnet
- allows traffic to traverse from subnet in VPC to internet and vice versa

## Network Access Control Lists (NACLs)
- virtual network level firewalls
- stateless
- default NACL created when VPC is created
	- all traffic allowed by default (therefore default NACL is insecure)
- two fundamental components
	1. Inbound Rules
	2. Outbound Rules
- final rule of NACL is that any traffic that isn't categorized by any of the rules gets dropped
- rules read in ascending order until match is found

## Security Groups
- similar to NACLs (provide virtual firewall) except operates at instance level rather than network level
- associated with instances rather than subnets
- controls traffic to and from instances within VPC
- stateful
- no field for *Allow* or *Deny* traffic, as all rules in security group are assumed to be allowed (traffic not categorized as such is dropped)
	- works as a whitelist for traffic
- all rules evaluated before decision is made

## Bastion Hosts
- used to gain access to instances that reside within private subnets
- bastion host resides within public subnet
- hardened EC2 instance with restrictive controls
- acts as ingress gateway

<u>Public Subnet</u>: a subnet associated with a route table pointing to an internet gateway (IGW) with a destination address of 0.0.0.0/0

- no packet is directly exchanged between internet and IPs inside private subnet (it goes first through the bastion host)

## NAT Instances and NAT Gateways
- kind of like the opposite of bastion host
- allows instances in private subnets to initiate a connection out to the internet via NAT resource
- blocks all inbound public-initiated traffic
- allows private instances access to internet
	- usually used for maintenance-related tasks such as updates

### NAT Gateway
- AWS managed resource
- offers enhanced bandwidth and availability in comparison to NAT instance
- requires far less administrative configuration than NAT instance