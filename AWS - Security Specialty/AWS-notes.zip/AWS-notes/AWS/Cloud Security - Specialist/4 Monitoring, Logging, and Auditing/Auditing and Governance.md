# Auditing and Governance
[[AWS Contents]]
[[AWS Questions#Auditing and Governance]]
## AWS Artifact
- on-demand portal allowing viewing and downloading AWS security and compliance reports and online agreements
	- these reports are undetaken by external auditors of AWS
	- agreements for accounts made with AWS 

## Securing with CloudTrail
- data (logs) can be encrypted with SSE-KMS
- SHA-256 used for file validation
- when validation is enabled, digest files are created
	- digest files reference every log file delivered within specific timeframe along with associated hash
	- digest files are signed using private key of a public/private key pair used by CloudTrail for that region

Validating if log was tampered with or moved:
`aws cloudtrail validate-logs --trail-arn <trailARN> --start-time <start-time>`

## AWS Config
- useful for seeing history of modifications to a resource via looking at the history of configuration items

Components of AWS Config:
- Configuration items
- Configuration streams
- Configuration history
- Configuration snapshots
- Configuration recorder
- Config rules
- Resource relationships
- Config role

### Configuration Items (CI)
- fundamental element of AWS Config
- contains point-in-time snapshot info on configuration data of attributes of an AWS resource such as:
	- current configuration
	- direct relationships resource has with other resources
	- metadata
	- events
- CI updated each time change is made on resource (e.g. create, update, or delete API call made against resource)

Components of Configuration Item:
**Metadata**: info and data about config item
**Attributes**: data of actual resource that CI relates to
**Relationship**: data related to any connected resource (e.g. if CI is related to a subnet, the relationship could contain data related to associated VPC that subnet is part of)
**Current Configuration**:  shows same info that would be generated upon performing a *describe* or *list* API call

## Amazon Macie
- managed service backed by machine learning
- automatically detects, protects, and classifies data within S3 buckets
- classifies data to determine its level of sensitivity