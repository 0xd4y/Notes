# Implementing Logging Mechanisms
[[AWS Contents]]
[[AWS Questions#Implementing Logging Mechanisms]]

## Amazon S3 Logging
- most common AWS storage service
- logs can be sent to S3 or Amazon CloudWatch Logs


Two types of logging within S3:
1. Server access logs
2. Object-level logs

### Server Access Logs
Log details captured:
- identity of requester accessing bucket
- name of bucket being accessed
- timestamp of when action was carried against bucket
- action that was done
- HTML response status
- any error codes
<br>
- source and target buckets must be in same region

### Object-Level Logging
- must be associated with CloudTrail which will record write and read API activity

### Flow Logs
- captures IP traffic across network interfaces
- default log file format:
```bash
${version} ${account-id} ${interface-id} ${srcaddr} ${dstaddr} ${srcport} ${dstport} ${protocol} ${packets} ${bytes} ${start} ${end} ${action} ${log-status}
```
1. version: version of the flow log
2. account-id: AWS account ID
3. interface-id: interface ID that log stream data applies to
4. srcaddr: IP source address
5. dstaddr: IP destination address
6. srcport: source port used for traffic
7. dstport: destination port for traffic
8. protocol: protocol number being used for traffic
9. packets: total number of packets sent during capture 
10. bytes: total number of bytes sent during capture
11. start: timestamp of when capture window started
12. end: timestamp of when capture windows finished
13. action: whether traffic was accepted or rejected by security groups
14. log-status: status of logging, which is one of three codes:
	- OK: data is being received
	- NoData: no traffic to capture during capture window
	- SkipData: some data within log was captured due to an error 

## VPC Traffic Mirroring
- duplicates network traffic from elastic network interfaces attached to instances
	- duplicated traffic sent to third-party tools and services for analysis

## CloudTrail
**Trails**: contain configurable options for what to monitor and track
**Events**: every API call is stored as an event
**Log Files**: created every 5 minutes; stored within S3 bucket
**CloudWatch Logs**: logs can be sent to CloudWatch for analysis and monitoring
**API Activity Filters**: provide search and filter functionality when looking at API activity

### Understanding CloudTrail Logs
<center>Example of CloudTrail Log</center>

```json
"awsRegion": "eu-west-1",
"eventID": "6ce47c89-5908-452d-87cc-a7c251ac4ac0",
"eventName": "PutObject",
"eventSource": "s3.amazonaws.com",
"eventTime": "2019-11-27T23:54:21Z",
"eventType": "AwsApiCall",
"eventVersion": "1.05",
"readOnly": false,
"recipientAccountId": "730739171055",
"requestID": "95BAC3B3C83CCC5D",
"requestParameters": {
"bucketName": "cloudtrailpackt",
"Host": "cloudtrailpackt.s3.eu-west-1.amazonaws.com",
"key": "Packt/AWSLogs/730739171055/CloudTrail/eu-west-
1/2019/11/27/730739171055_CloudTrail_eu-west-
1_20191127T2321Z_oDOj4tmndoN0pCW3.json.gz",
"x-amz-acl": "bucket-owner-full-control",
"x-amz-server-side-encryption": "AES256"
"sharedEventID": "11d4461b-0604-46c4-b4c9-6a23b3e7f57c",
"sourceIPAddress": "cloudtrail.amazonaws.com",
"userAgent": "cloudtrail.amazonaws.com",
"userIdentity": {
"invokedBy": "cloudtrail.amazonaws.com",
"type": "AWSService"
```
- shows Cloudtrail made *PutObject* request to Amazon S3 to store its log file (see the *key* parameter)

*eventName*: name of API called
*eventSource*: AWS service in which API call was made
*eventTime*: time of API call
*SourceIPAddress*: IP that made the API call (if a service did the API call then instead the name of the service would be displayed)
*userAgent*: agent method of request
*Console.amazonaws.com*: determines that root user made request
*userIdentity*: additional info relating to user agent

### Amazon Athena
- serverless service
- analyzes data stored within Amazon S3 (such as CloudTrail logs)
- uses SQL 

### CloudWatch
- main AWS monitoring service
- collects data and metrics from all supported AWS services 
- can be implemented in a large scale using AWS Systems Manager (SSM)

