# Managing Data Security
[[AWS Contents]]
[[AWS Questions#Managing Data Security]]

## Amazon EBS Encryption
- EBS volumes provide block-level storage to EC2 instance
	- gives more flexibility for storage capabilities
- default regional encryption setting can be applied to EBS volumes to automatically encrypt new EBS volumes 
- uses KMS service to encrypt data

## Amazon EBS
- used for file-level storage
- support in-transit and at-rest encryption
- uses KMS service to encrypt data

## Amazon S3
- provides object-level storage

Five different encryption options for S3 objects:
1. Server-side encryption with S3-managed keys (SSE-S3)
2. Server-side encryption with KMS-managed keys (SSE-KMS)
3. Server-side encryption with customer-managed keys (SSE-C)
4. Client-side encryption with KMS-managed keys (CSE-KMS)
5. Client-side encryption with customer-managed keys (CSE-C)

- server-side encryption: encryption algorithm and process run from server-side (i.e. in this case it is within Amazon S3)
- client-side encryption: encryption process executed on client side before data sent to S3

### SSE-S3
#### Encryption
![[Pasted image 20220225215402.png]]
1. Client selects object(s) to upload to S3 and indicates SSE-S3 as encryption algorithm
2. S3 encrypts object with plaintext data key and encrypted object stored in chosen S3 bucket
3. plaintext data key encrypted with S3 master key, and the encrypted key is then stored into S3 and associated with encrypted data object
4. Plaintext data key removed from memory

#### Decryption
![[Pasted image 20220225215755.png]]
1. User request encrypted object
2. Encrypted data key of object is decrypted with S34 master key
3. Plaintext data key decrypts encrypted data object
4. S3 returns plaintext data object to client

### SSE-KMS
#### Encryption
[[Managing Key Infrastructure#SSE-KMS Encryption]]
#### Decryption
[[Managing Key Infrastructure#SSE-KMS Decryption]]

### SSE-C
#### Encryption
![[Pasted image 20220225220028.png]]

1. Client uploads object to S3 along with plaintext customer-provided key across HTTPS
	- mandatory to use HTTPS
2. Object is encrypted with key and a salted HMAC value of customer key is generated for validation upon future access requests. HMAC value and encrypted object stored in S3 with association to each other. Plaintext key removed.

#### Decryption
![[Pasted image 20220225234838.png]]
1. User requests encrypted object via HTTPS. Customer key sent to S3.
2. S3 uses stored HMAC value of key to validate the client sent the correct key.
3. Customer key used to decrypt object data.
4. Plaintext object sent to client.

### CSE-KMS
#### Encryption
![[Pasted image 20220225235024.png]]
1. Client uses AWS SDK (Software Development Kit) to request data keys from KMS using specified CMK
2. KMS genrate two data keys using the CMK: plaintext data key and cipher blob of that key
3. KMS sends the keys back to requesting client
4. Client encrypts object data with plaintext version of data key and stores the resulting encrypted object.
5. Client uploads encrypted object data and cipher blob version of key to S3. 
6. Cipher blob key stored as metadata against encrypted object.

#### Decryption
![[Pasted image 20220225235449.png]]
1. User requests access to encrypted S3 object.
2. Encrypted object sent to client with associated cipher blob key.
3. Cipher blob sent back to KMS to generate data key.
4. KMS uses original CMK along with cipher blob to generate a plaintext version of data key.
5. Plaintext data key sent back to requesting Java client.
6. Java client uses plaintext key to decrypt object.

### CSE-C
#### Encryption
![[Pasted image 20220225235650.png]]
1. Java client create plaintext data key to encrypt object data.
2. CMK created by customer encrypts plaintext data key.
3. Encrypted data key and encrypted object sent from client to S3 storage.
4. S3 associates encrypted data key with encrypted object and stores both in S3.

#### Decryption
![[Pasted image 20220225235831.png]]
1. Uses requests access to encrypted object.
2. S3 sends requested object data with associated encrypted data key.
3. Customer CMK used with encrypted data key to generate plaintext version of data key.
4. Encrypted object decrypted using plaintext data key.

## Amazon RDS
- database service
- encryption at rest uses AES-256
- can only encrypt RDS database during its creation
- SSL/TLS used for in-transit encryption

## Amazon DynamoDB
- fully managed key-value and document NoSQL database
- at-rest server-side encryption enabled by default
	- this setting cannot be disabled

Three options to encrypt data with:
1. DEFAULT: key owned by Amazon DynamoDB
2. KMS - Customer managed CMK
3. KMS - AWS managed CMK

- encryption in transit uses HTTPS
