# Managing Key Infrastructure
[[AWS Contents]]
[[AWS Questions#Managing Key Infrastructure]]

## AWS Key Management Service (KMS)
- managed service
- allows you to create, store, rotate, and delete encryption keys
- unlike SSL, KMS not designed for encryption-in-transit
- supports symmetric and asymmetric CMKs

### Customer Master Keys (CMK)
- building block of KMS
- contains material used for encrypting and decrypting data

Three different types of CMKs:
1. AWS-owned
	- rotation period varied from service to service
	- managed and created by AWS
	- e.g. Amazon S3 encryption using S3 master key (SSE-S3)
	- can't view keys
2. AWS-managed
	- can't control rotation frequency
	- can view keys being used and track their usage and key policies
3. Customer-managed
	- full control of keys

### Data Encryption Keys (DEKs)
- created by CMKs
- unlike CMKs, doesn't reside within KMS service
- used outside of KMS to encrypt data
- when DEK is generated, the associated CMK will create two DEKs
	1. Plaintext Key
	2. Identical (Encrypted) Key
- <u>Envelope Encryption</u>: using one key to encrypt another key

Amazon S3 server-side encryption and decryption with KMS managed keys (SSE-KMS):
#### SSE-KMS Encryption
![[Pasted image 20220224222854.png]]
1. SSE-KMS encryption mechanism chosen by client and either AWS-managed or customer-managed CMK is selected
2. S3 tells KMS to generate DEKs 
3. Plaintext data key and identical (encrypted) data key generated
4. These data keys are sent to S3. 
5. S3 encrypts object data with plaintext version of data key. Encrypted data is then stored with encrypted version of key. Plaintext data key is destroyed.  

#### SSE-KMS Decryption
![[Pasted image 20220224223534.png]]
1. Request received by S3 to access encrypted object 
2. S3 sends encrypted data key associated with object to KMS
3. KMS uses original CMK to decrypt the data key to generate a plaintext version of that key
4. KMS sends plaintext data key to S3
5. Encrypted object decrypted with that key
6. Plaintext object sent back to client

### Key Material
<u>Key Material</u>: Data used to encrypt and decrypt data
- stored within CMK
- CMK key material can be used to encrypt data key and decrypt it (see [[Managing Key Infrastructure#SSE-KMS Decryption|SSE-KMS Decryption]])
- key material for AWS-managed CMKs gets automatically created
- customer-managed CMKs give option of adding key material or not
	- can even import your own key material known as Bring Your Own Key (BYOK)
	- BYOK doesn't support automatic key rotation

### Key Policies
- cannot control access to CMKs without key policies
- access to CMK can be configured via:
	1. Key Policies: All access governed by key policy
	2. Key Policies and IAM: Access governed by key policy and IAM identity-based policies
		- allows access via groups and other IAM features
	3. Key Policies and Grants: Access governed by key policy with ability to delete access to other for using the CMK
		- check page 508-512, great explanation
	
## AWS CloudHSM
- fully managed service used for data encryption
- can integrate with KMS in the form of using CloudHSM as a custom key store
	- allows storage of CMKs outside of KMS and into CloudHSM cluster
- HSM stands for Hardware Security Module
	- generates keys and stores them
	- can use different encryption algorithms for both symmetric keys and asymmetric keys
	- manages symmetric and asymmetric keys
	- signs and verifies signatures
	- can use hash function to compute hash-based message authentication codes (HMACs)

### Cloud HSM Users
User types of CloudHSM
1. Precrypto Office
2. Crypto Office
3. Crypto User
4. Appliance User

Operations | PRECO | CO | CU| AU|
-----|-----|-------|------|-----|
Obtain basic cluster information (number of HSMs in cluster, IP address, serial number, etc.) | No | Yes | Yes | Yes
Zeroize HSMs (delete keys, certificates, and data  on the HSM) | No | Yes | Yes | Yes
Change own password | Yes | Yes | Yes | Yes
Change any user's password | No | Yes | No | No
Add and remove users | No | Yes | No | No
Get synchronization status | No | Yes | Yes | Yes
Key management operations | No | No | Yes | No
Encrypt, decrypt, sign, verify, generate, and digest HMACs | No | No | Yes | No
#### Precrypto Office (PRECO)
- automatically created upon creating first HSM within cluster
- PRECO user has default creds
- when first connecting to the HSM, you are prompted to change password of PRECO user
	- this turns the PRECO user into a Crypto Office (CO) user

#### Crypto Office (CO)
- greater permissions than PRECO

Permissions:
- create, delete and change passwords of users
- delete keys, certificates, and data on HSM
- obtain HSM metadata

#### Crypto User (CU)
Permissions:
- perform encryption and decryption
- create, delete, wrap, unwrap, and mofity attributes of key
- signs and verifies
- generate digests and HMACs

#### Appliance User (AU)
- exists on all HSMs
- clones and synchronizes actions of HSMs
- has same permissions as CO but cannot change passwords or add/remove user

## AWS Secrets Manager
- managed service
- secrets retrieved by calling Secrets Manager API
<u>Secrets</u>: Anything that is confidential (e.g. passwords, API keys, etc.)
- removes need for hardcoding credentials in code
- automatically rotates secrets

