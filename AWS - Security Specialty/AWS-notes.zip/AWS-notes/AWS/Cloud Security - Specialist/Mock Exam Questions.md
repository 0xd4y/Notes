# Mock Exam Questions 
- questions I got wrong or was unsure about

## Mock Exam 1
1. When IAM policies are being evaluated for their logic of access, which two of the following statements are incorrect?

	- explicit denies are always overruled by an explicit allow
	- access to all resources is allowed by default until access is denied

2. Your security team has been tasked with implementing a solution to monitor your EC2 fleet of instances. Upon review, you decide to implement Amazon Inspector. What are the three prerequisites that you would need to implement before using Amazon Inspector? (Choose three answers)

	- deploy Amazon Inspector agents to your EC2 fleet
	- create an IAM service-linked role that allows Amazon Inspector to access your EC2 feet

4. When using AWS Shield, which type of rule counts the number of requests received from a particular IP address over a time period of 5 minutes?

	- rate-based

5. Following a breach on your network, an instance was compromised and you need to perform a forensic investigation of the affected instance. You decide to move the EC2 instance to your forensic account. Which steps would you take to carry out this process?

- Create an AMI from the affected EC2 instance and then share that AMI image with your forensic account. From within your forensic account, locate the AMI and create a new instance from the shared AMI.

6. What is the Log Delivery Group account used for within Amazon S3?

	- This is a predefined group by AWS that's used to deliver S3 server access logs to a bucket.

10. You are using the KMS service called encrypt_me to perform encryption within Amazon S3 using a customer created CMK in eu-west-1. A colleague explains that they are unable to see the CMK when they try to use it to encrypt data in a bucket named encrypt_me_too in us-east-1. What is the most likely cause of this?

	- CMKs are regional, so it will not appear in us-east-1.

11. A developer in your organization requires access to perform cryptographic functions using a customer-managed CMK. What do you need to update so that you can add permissions for the developer to allow them to use the CMK?

	- Key policy

14. Your IAM administrator has created 20 IAM users within your organization's production AWS account. All users must be able to access AWS resources using the AWS Management Console, in addition to programmatic access via the AWS CLI. Which steps must be implemented to allow both methods of access? (Choose two.)

	- Create a user account with their own IAM credentials and password.
	- Create an access key and secret access key for every user.

16. Microsoft Active Directory Federation Services (ADFS) can be used as an Identity Provider (IdP) to enable federated access to the AWS Management Console. As part of the authentication process, which API is used to request temporary credentials to enable access?

	- AssumeRoleWithSAML

17. When configuring your IdP from within IAM, which document do you need to provide that includes the issuer's name, expiration information, and keys that can be used to validate the SAML authentication response (assertions) that are received from the IdP?

	- Metadata document

18. Your CTO has asked you to find a simple and secure way to perform administrative tasks and configurational changes remotely against a selection of EC2 instances within your production environment. Which option should you choose?

	- Use the Run command in AWS Systems Manager.

19. Your organization is running a global retail e-commerce website in which customers from around the world search your website, adding products to their shopping cart before ordering and paying for the items. During a meeting to redesign the infrastructure, you have been instructed to define a solution where routing APIs to microservices can be managed, in addition to adding security features so that users can manage authentication and access control and monitor all requests that are made from concurrent API calls. Which service should you implement to manage these requirements?

	- AWS API Gateway

21. One of your instances within a private subnet of your production network may have been compromised. Since you work within the incident team, you have been asked to isolate the instance from other resources immediately, without affecting other production EC2 instances in the same subnet. Which approaches should be followed in this situation? (Choose two.)

	- remove any role associated with the EC2 instance
	- change security group of instance to restricted security group, thereby preventing any access to or from the instance
	
22. You have implemented a VPN connection between your data center and your AWS VPC. You then enabled route propagation to ensure that all the other routes to networks represented across your site-to site VPN connection are automatically added within your route table. However, you notice that you now have overlapping CIDR blocks between your propagated routes and existing static routes. Which statement is true?

	- Your static routes will take precedence over propagated routes

23. Your CTO has explained that they are looking for a solution to be able to monitor network packets across your VPC. You suggest VPC flow logs, but the CTO wants to implement a solution whereby captured traffic is sent to a Network Load Balancer, using UDP as a listener, which sits in front of a fleet of appliances dedicated to network analysis. What solution would you suggest to the CTO?

	- Use Traffic Mirroring to capture packets and use the NLB as a Target.

24. You have been tasked with defining a central repository that enables you to view real-time logging information from different AWS services that can be filtered and queried to search for specific events or error codes. Which of the following would you use?

	- Amazon CloudWatch logs

25. Which feature of AWS CloudTrail can be used for forensic investigation to confirm that your log files have not been tampered with?

	- Select Log File Validation

31. When encrypting an EBS group, which kind of keys can be used? (Choose three.)

	- AWS managed CMK key
	- AWS owned CMK key
	- Customer CMK key

34. Which policies do NOT require a principal parameter within the context of the policy? (Choose two.)

	- An inline IAM policy
	- A service control policy (SCP)

35. You have just joined a new startup as a security engineer. One of your first tasks is to implement authentication for a new mobile application that is likely to scale to over a million users within the first few months. Which option is the best for handling scaling with minimal management?

	- Implement Amazon Cognito with Social Federation.

36. Your engineering team has come to you to explain that they have lost the private key associated with one of their Linux instance-stored backed root volume EC2 instances, and they can no longer connect to and access the instance. Which statement is true in this circumstance?

	- When you lose your private key to an EC2 instance that has an instance-stored root volume, there is no way to reestablish connectivity to the instance

37. You are explaining the differences between security groups and Network Access Control Lists to a customer. What key points are important to understand when understanding how these two security controls differ from each other? (Choose three)

	- Security groups are stateful by design and NACLs are not
	- Securiyt groups controll access at the instance level
	- NACLs allow you to add a `deny` action within the ruleset

38. Your new startup is deploying a highly-scalable multi-tiered application. Your VPC is using both public and private subnets, along with an application load balancer. Your CTO has defined the following requirements:

	- a NAT gateway should be deployed in the public subnet
	- Launch the EC2 instances in the private subnet

39. You are experiencing an increase in the level of attacks across multiple different AWS accounts against your applications from the internet. This includes XSS and SQL injection attacks. As the security architect for your organization, you are responsible for implementing a solution to help reduce and minimize these threats. Which AWS services should you implement to help protect against these attacks? (Choose two.)

	- AWS Firewall Manager
	- AWS Web Application Firewall

40. During the deployment of a new application, you are implementing a public-facing Elastic Load Balancer (ELB). Due to the exposed risk, you need to implement encryption across your ELB, so you select HTTPS as the protocol listener. During this configuration, you will need to select a certificate from a certificate authority (CA). Which CA is the recommended choice for creating the X.509 certificate?

	- AWS Certificate Manager

41. Recently, you have noticed an increase in the number of DDoS attacks against your public web servers. You decide to implement AWS Shield Advanced to help protect your EC2 instances. Which configurational change do you need to implement before you can protect your instance using the advanced features?

	- Assign an EIP to the EC2 instance.

42. Which layer of the OSI model do both Amazon CloudFront (with AWS WAF) and Route 53 offer attack mitigation against? (Choose three.)

	- They offer attack mitigation against layers 3,4, and 7

45. An engineer has raised a concern regarding one of your buckets and wants to understand details about when a particular bucket has been accessed to help ascertain the frequency and by whom. Which method would be the MOST appropriate to get the data required?

	- Analyze S3 Server Access Logs

46. Amazon S3 object-level logging integrates with which other AWS service?

	- AWS CloudTrail

47. You are currently monitoring the traffic flow between a number of different subnets using VPC flow logs. Currently, the configuration of the capture is capturing ALL packets. However, to refine the flow log details, you want to modify the configuration of the flow log so that it only captures rejected packets instead. Which of the following statements is true?

	- You can't change the configuration of an existing flow log once it's been created.

48. Your CTO is concerned about the sensitivity of the data being captured by AWS CloudTrail. As a result, you suggest encrypting the log files when they are sent to S3. Which encryption mechanism is available to you during the configuration of your Trail?

	- SSE-KMS

49. As part of your security procedures, you need to ensure that, when using the Elastic File System (EFS), you enable encryption-in-transit using TLS as a mount option, which uses a client tunnel process. Assuming your filesystem is fs-12345678 and your filesystem's identifier is /mnt/efs, which command would you enter to mount the EFS file stems with encryption enabled?

	- `sudo mount -t efs -o tls fs-12345678:/ /mnt/efs`

50. You are configuring your AWS environment in preparation for downloading and installing the CloudWatch agent to offer additional monitoring. Which two tasks should you complete prior to installing the agent?

	- Ensure that your EC2 instance is running the latest version of the SSM agent.
	 - Ensure that your EC2 instances have outbound internet access.

51. You have been approached by your compliance team to define what data is encrypted on an EBS volume when EBS encryption has been enabled. Which of the following should you choose? (Choose three.)

	- the root and data volume
	- All data moving between the EBS volume and the associated EC2 instance
	- All snapshots of the EBS volume

52. You are being audited by an external auditor against PCI-DSS, who is accessing your solutions that utilize AWS. You have been asked to provide evidence that certain controls are being met against infrastructure that is maintained by AWS. What is the best way to provide this evidence?

	- Use AWS Artifact to download the appropriate compliance records.

53. Which part of AWS CloudHSM can carry out the following functions? 
- Perform encryption and decryption.
- Create, delete, wrap, unwrap, and modify attributes of keys.
- Sign and verify.
- Generate digests and HMACs.
<br>
	Crypto User (CU)
	
56. Amazon GuardDuty uses different logs to process and analyze millions of events that are then referenced against numerous threat detection feeds, many of which contain known sources of malicious activity, including specific URLs and IP addresses. Which of the following logs are NOT used by Amazon GuardDuty? (Choose two.)

	- S3 Server Access logs
	- CloudWatch Event logs

59. You have been asked to upload the company's own key material instead of using the key material generated by KMS. In preparation for doing this, you download the public key and import token. What format must your key material be in prior to it being uploaded?

	- Binary

61. Which of the following is NOT considered an asymmetric key encryption mechanism?

	- Advanced Encryption Standard (AES)

62. AWS Trusted Advisor helps customers optimize their AWS environment through recommended best practices. Which of the following is NOT one of the five categories that it checks in your account?

	- Monitoring

63. Which of the following keys shows an AWS managed key when using Amazon S3 SSE-KMS?

	- aws/s3

64. Which keys used in conjunction with KMS are used outside of the KMS platform to perform encryption against your data?

	- Data encryption key