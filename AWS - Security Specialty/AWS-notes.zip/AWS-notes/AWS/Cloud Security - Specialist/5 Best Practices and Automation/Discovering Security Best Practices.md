# Discovering Security Best Practices
[[AWS Contents]]
[[AWS Questions#Discovering Security Best Practices]]
 - Multi-Factor Authentication (MFA)
 - Enable AWS CloudTrail
 - Remove root account access keys
	 - account keys enabled access via AWS CLI, SDK, or other development tools
 - Strong passwords
 - Principle of Least Privilege (PoLP)
 - Encrypt data
 - Automate security threat detection and remediation
 
 ## AWS Trusted Advisor
 - recommends enhancements against number of predefined best practice checks across five areas of your account:
	 1. Cost optimization
		 - identifies resources not optimally used
	 2. Performance
		 - looks for resources that could make use of provisioned throughput
		 - identifies over-utilized resources
	 3. Security
		 - identifies weaknesses 
	 4. Fault Tolerance
		- determines whether you have adequate resiliency built into environment
	 5. Service Limits
		 - checks if services have reached 80% of allotted service limit

## Pentesting AWS
- can't carry pentest against some services without prior approval from AWS
- services you can pentest against:
	- Amazon EC2 instances, NAT gateways, and elastic load balancers
	- Amazon RDS
	- Amazon CloudFront
	- Amazon Aurora
	- Amazon API Gateways
	- AWS Lambda and Lambda Edge functions
	- Amazon Lightsail resources
	- Amazon Elastic Beanstalk environments
- services not to be pentested:
	- DNS zone walking via Amazon Route 53 hosted zones
	- Denial of Service (DoS), Distributed Denial of Service (DDoS),
	- simulated DoS, simulated DDoS
	- Port flooding
	- Protocol flooding
	- Request flooding (login request flooding and API request flooding)