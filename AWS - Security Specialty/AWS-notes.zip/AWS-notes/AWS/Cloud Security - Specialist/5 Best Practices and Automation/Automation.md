# Automation
[[AWS Contents]]
[[AWS Questions#Automation]]

## Automating Security Detection and Remediation
### Using CloudWatch Events with AWS Lambda and SNS
- can identify event to capture and create an automatic response
#### AWS Lambda 
- serverless compute service
- automatically provisions compute power
- allows running code for applications either on demand or in response to events without needing to provision any compute instances yourself
- allows freedom of not having to maintain a compute instance (this is handled by AWS)

### Amazon GuardDuty
- can be used for automation detection and remediation 
- powered by machine learning
- can capture events from CloudTrail logs, DNS logs, and VPC flow flogs
	- events referenced against threat detection feeds (compared against known sources of malicious activity)
- runs on AWS infrastructure so doesn't affect performance of your infrastructure

### AWS Security Hub
- collects security findings from:
	- AWS IAM
	- Amazon Macie
	- Amazon GuardDuty
	- Amazon Inspector
	- AWS Firewall Manager
- has predefined and managed insights to identify security-related weaknesses
